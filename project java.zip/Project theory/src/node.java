/*
NODE CLASS
*/

public class node {

    Song s;
    node next;
    node prev;

    node(Song s) {
        this.s = s;
        this.next = null;
        this.prev = null;
    }

    public void displayDoublyNode() {
        System.out.println(s.showSong() + " ");
    }
}