/*
DOUBLE LINKED LIST CLASS
*/
public class DLL {

    node head;
    node tail;
    int length = 0;

    DLL() {
        head = null;
        tail = null;
    }

    public void addSong(Song s) {
        node newNode = new node(s);
        if (head == null) {
            head = newNode;
            tail = newNode;
            length++;
        } else {
            newNode.prev = tail;
            tail.next = newNode;
            tail = newNode;
            length++;
        }
    }

    public int length() {
        return length;
    }

    public node getfirst() {
        System.out.println(head.s.showSong());
        return head;
    }

    public void displayList() {
        node temp = head;
        while (temp != null) {
            temp.displayDoublyNode();
            temp = temp.next;
        }
    }
    
    public void deleteLastSong() {
        if (head == null) {
            System.out.println("the list is empty");
        } else if (head.next == null) {
            head = null;
            tail = null;
        } else {
            tail = tail.prev;
            tail.next.prev = null;
            tail.next = null;
        }
    }
    
    public void removeSong(int pos) {
        if (head == null) {
            length--;
            return;
            
        } else {
            node temp = head;

            for (int i = 1; i < pos; i++) {
                temp = temp.next;
                length--;
            }

            if (temp == head) {
                head = temp.next;
                length--;
            } else if (temp == tail) {
                deleteLastSong();
                length--;
            } else {
                temp.prev.next = temp.next;
                temp.next.prev = temp.prev;
                length--;
            }
        }
    }
}