/*
 PLAYLIST CLASS/ MAIN CLASS
 */

import java.util.Scanner;

public class Playlist {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
String palylistname;
    DLL theList = new DLL();
        DLL list =new DLL();
        System.out.println("*********************\n");
        System.out.println("---------------------------Welcome All-------------------\n"
              + "------------------- Create Your Own Playlist---------------");
        System.out.println("*********************\n");
        
           
            
          
            boolean sec=true;
            while(sec){
         System.out.println("You want to create new playlist");
          System.out.println("\n Enter 1) yes:  " +  "\n"
                    + " Enter 2) NO: " +  "\n");
          
          int choice=input.nextInt();
          
          switch(choice){
              case 1:
                  
                     System.out.println("Please Enter your Playlist Name");
        input.nextLine();
        String playlistname=   input.nextLine();
    playlistname p = new playlistname(playlistname);
                    list.addplaylist(p);
                     System.out.println("");
                    break;
                    
              case 2:
                  
                 
                 
                  
                  
                  boolean thir=true;
            while(thir){
         
          System.out.println("\n Enter 1) SELECT PLAYLIST:  " +  "\n"
                    + " Enter 2) DELETE PLAYLIST: " +  "\n"
                    + " Enter 3) Go back: " +  "\n");
          
          int choice3=input.nextInt();
          switch(choice3){
              case 1:
                    if (list.length() == 0) {
                        System.out.println("No  Playlist  found");
                        break;

                    } else {
                        System.out.println("Here are  the playList ");
                        
                        
                        
                         boolean four=true;
                         while(four){
                             list.displayplayList();
                              System.out.println("Select Your playlist  or press 0 to go back ");
                               int choice4=input.nextInt();
                               switch(choice4){
                                   
                                   case 0:
                                       four=false;
                                       break;
                               case 1:
                                           boolean first = true;
        while (first) {
           
            
            System.out.println("\n Enter 1) To Add Songs To Playlist  "  + "\n"
                    + " Enter 2) To remove Songs From Playlist "  + "\n"
                    + " Enter 3) To show the songs in Playlist "  + "\n"
                    + " Enter 4) To Play The Playlist " +  "\n"
                    + " Enter 5) To Exit");
            int choice1 = input.nextInt();
            switch (choice1) {
                case 1:
                    System.out.println("Enter The name of the Song");
                    input.nextLine();
                    String songname = input.nextLine();
                    System.out.println("Enter The Name of the artist");
                    String artist = input.nextLine();
                    System.out.println("Enter The Duration of the song");
                    String duration = input.nextLine();
                    Song s = new Song(songname, artist, duration);
                    theList.addSong(s);
                    System.out.println(songname + " Song is added to playlist " + "!!!\n" );
                    break;

                case 2:
                    if (theList.length() == 0) {
                        System.out.println("No Songs present in the Playlist: " + list.head);
                        break;

                    } else {
                        System.out.println("Here is the List of Songs");
                        theList.displayList();
                        System.out.println("Enter The index of the Song to remove, first Song is at index 1");
                        int index = input.nextInt();

                        if (index <= 0 || index > theList.length()) {
                            System.out.println("No Song in that index");

                        } else {
                            theList.removeSong(index);
                            System.out.println("Song Removed !!");

                        }
                        break;
                    }

                case 3:
                    if (theList.length() == 0) {
                        System.out.println("No Songs in the Playlist");
                        break;

                    } else {
                        System.out.println("Here is the List of Songs");
                        theList.displayList();
                        break;

                    }
                case 4:
                    
     
                    
                    if (theList.length() == 0) {
                        System.out.println("No Songs in the Playlist");
                        break;

                    } else {
                        System.out.println("Here is the List of Songs");
                        theList.displayList();
                        System.out.println("");
                        System.out.println("Current Song-----");
                        System.out.println("");
                        node i = theList.getfirst();

                        boolean second = true;
                        while (second) {
                            System.out.println(" \n Enter 1) To play the next song \n"
                                    + " Enter 2) To play the previous song \n"
                                    + " Enter 3) To play the same song again \n"
                                    + " Enter 4) To stop the playlist ");

                            int choice2 = input.nextInt();

                            switch (choice2) {
                                case 1:
                                        
                                    node temp;
                                    temp = theList.head;
                                    node temp1=theList.tail;
                                   if(i==temp1) {
                                     
                                      i=theList.getfirst();
                                     

                                    }
                                    if (i == temp) {

                                        i = temp.next;
                                        System.out.println(i.s.showSong());

                                    } else if (i != temp) {
                                        i = i.next;
                                        System.out.println(i.s.showSong());
                                    }
                                   
                                    break;
                                case 2:

                                    node temp2 = theList.head;
                              

                                    if (i == temp2) {
                                          
                                        System.out.println("Emptylinklist");
                                    } else if (i != temp2) {
                                        i = i.prev;
                                        System.out.println(i.s.showSong());
                                    }

                                    break;
                                case 3:

                                    System.out.println(i.s.showSong());

                                    break;

                                case 4:
                                    second = false;

                                    break;

                                default:
                                    second = false;

                                    break;
                            }
                        }
                    }
                    break;
                    
                case 5:
                    first = false;
                    break;

                default:
                    first = false;

                    break;

            }
            
         

    }
        
           break;
            case 2:
                  boolean firstsub2 = true;
        while (firstsub2) {
           
            
            System.out.println("\n Enter 1) To Add Songs To Playlist  "  + "\n"
                    + " Enter 2) To remove Songs From Playlist "  + "\n"
                    + " Enter 3) To show the songs in Playlist "  + "\n"
                    + " Enter 4) To Play The Playlist " +  "\n"
                    + " Enter 5) To Exit");
            int choice1 = input.nextInt();
            switch (choice1) {
                case 1:
                    System.out.println("Enter The name of the Song");
                    input.nextLine();
                    String songname = input.nextLine();
                    System.out.println("Enter The Name of the artist");
                    String artist = input.nextLine();
                    System.out.println("Enter The Duration of the song");
                    String duration = input.nextLine();
                    Song s = new Song(songname, artist, duration);
                    theList.addSong(s);
                    System.out.println(songname + " Song is added to playlist " + "!!!\n" );
                    break;

                case 2:
                    if (theList.length() == 0) {
                        System.out.println("No Songs present in the Playlist: " + list.head);
                        break;

                    } else {
                        System.out.println("Here is the List of Songs");
                        theList.displayList();
                        System.out.println("Enter The index of the Song to remove, first Song is at index 1");
                        int index = input.nextInt();

                        if (index <= 0 || index > theList.length()) {
                            System.out.println("No Song in that index");

                        } else {
                            theList.removeSong(index);
                            System.out.println("Song Removed !!");

                        }
                        break;
                    }

                case 3:
                    if (theList.length() == 0) {
                        System.out.println("No Songs in the Playlist");
                        break;

                    } else {
                        System.out.println("Here is the List of Songs");
                        theList.displayList();
                        break;

                    }
                case 4:
                    
     
                    
                    if (theList.length() == 0) {
                        System.out.println("No Songs in the Playlist");
                        break;

                    } else {
                        System.out.println("Here is the List of Songs");
                        theList.displayList();
                        System.out.println("");
                        System.out.println("Current Song-----");
                        System.out.println("");
                        node i = theList.getfirst();

                        boolean second = true;
                        while (second) {
                            System.out.println(" \n Enter 1) To play the next song \n"
                                    + " Enter 2) To play the previous song \n"
                                    + " Enter 3) To play the same song again \n"
                                    + " Enter 4) To stop the playlist ");

                            int choice2 = input.nextInt();

                            switch (choice2) {
                                case 1:
                                        
                                    node temp;
                                    temp = theList.head;
                                    node temp1=theList.tail;
                                   if(i==temp1) {
                                     
                                      i=theList.getfirst();
                                     

                                    }
                                    if (i == temp) {

                                        i = temp.next;
                                        System.out.println(i.s.showSong());

                                    } else if (i != temp) {
                                        i = i.next;
                                        System.out.println(i.s.showSong());
                                    }
                                   
                                    break;
                                case 2:

                                    node temp2 = theList.head;
                              

                                    if (i == temp2) {
                                          
                                        System.out.println("Emptylinklist");
                                    } else if (i != temp2) {
                                        i = i.prev;
                                        System.out.println(i.s.showSong());
                                    }

                                    break;
                                case 3:

                                    System.out.println(i.s.showSong());

                                    break;

                                case 4:
                                    second = false;

                                    break;

                                default:
                                    second = false;

                                    break;
                            }
                        }
                    }
                    break;
                    
                case 5:
                    firstsub2 = false;
                    break;

                default:
                    firstsub2 = false;

                    break;

            }
            
         

    }
        break;
            case 3:
          boolean firstsub3 = true;
        while (firstsub3) {
           
            
            System.out.println("\n Enter 1) To Add Songs To Playlist  "  + "\n"
                    + " Enter 2) To remove Songs From Playlist "  + "\n"
                    + " Enter 3) To show the songs in Playlist "  + "\n"
                    + " Enter 4) To Play The Playlist " +  "\n"
                    + " Enter 5) To Exit");
            int choice1 = input.nextInt();
            switch (choice1) {
                case 1:
                    System.out.println("Enter The name of the Song");
                    input.nextLine();
                    String songname = input.nextLine();
                    System.out.println("Enter The Name of the artist");
                    String artist = input.nextLine();
                    System.out.println("Enter The Duration of the song");
                    String duration = input.nextLine();
                    Song s = new Song(songname, artist, duration);
                    theList.addSong(s);
                    System.out.println(songname + " Song is added to playlist " + "!!!\n" );
                    break;

                case 2:
                    if (theList.length() == 0) {
                        System.out.println("No Songs present in the Playlist: " + list.head);
                        break;

                    } else {
                        System.out.println("Here is the List of Songs");
                        theList.displayList();
                        System.out.println("Enter The index of the Song to remove, first Song is at index 1");
                        int index = input.nextInt();

                        if (index <= 0 || index > theList.length()) {
                            System.out.println("No Song in that index");

                        } else {
                            theList.removeSong(index);
                            System.out.println("Song Removed !!");

                        }
                        break;
                    }

                case 3:
                    if (theList.length() == 0) {
                        System.out.println("No Songs in the Playlist");
                        break;

                    } else {
                        System.out.println("Here is the List of Songs");
                        theList.displayList();
                        break;

                    }
                case 4:
                    
     
                    
                    if (theList.length() == 0) {
                        System.out.println("No Songs in the Playlist");
                        break;

                    } else {
                        System.out.println("Here is the List of Songs");
                        theList.displayList();
                        System.out.println("");
                        System.out.println("Current Song-----");
                        System.out.println("");
                        node i = theList.getfirst();

                        boolean second = true;
                        while (second) {
                            System.out.println(" \n Enter 1) To play the next song \n"
                                    + " Enter 2) To play the previous song \n"
                                    + " Enter 3) To play the same song again \n"
                                    + " Enter 4) To stop the playlist ");

                            int choice2 = input.nextInt();

                            switch (choice2) {
                                case 1:
                                        
                                    node temp;
                                    temp = theList.head;
                                    node temp1=theList.tail;
                                   if(i==temp1) {
                                     
                                      i=theList.getfirst();
                                     

                                    }
                                    if (i == temp) {

                                        i = temp.next;
                                        System.out.println(i.s.showSong());

                                    } else if (i != temp) {
                                        i = i.next;
                                        System.out.println(i.s.showSong());
                                    }
                                   
                                    break;
                                case 2:

                                    node temp2 = theList.head;
                              

                                    if (i == temp2) {
                                          
                                        System.out.println("Emptylinklist");
                                    } else if (i != temp2) {
                                        i = i.prev;
                                        System.out.println(i.s.showSong());
                                    }

                                    break;
                                case 3:

                                    System.out.println(i.s.showSong());

                                    break;

                                case 4:
                                    second = false;

                                    break;

                                default:
                                    second = false;

                                    break;
                            }
                        }
                    }
                    break;
                    
                case 5:
                    firstsub3 = false;
                    break;

                default:
                    firstsub3 = false;

                    break;

            }
            
         

    }//end of while loop sub3
            default:
                four=false;
                break;
                               }//end switch choice 4
                               
                         }//end of while loop four

                    } //end of if else
                    
                    
                    break;
                    
          
            
                    
              case 2:
               
                   if (list.length() == 0) {
                        System.out.println("No  Playlist found: " + list.head);
                        break;

                    } else {
                        System.out.println("Here are the playlist");
                        list.displayplayList();
                        System.out.println("Enter The index of the playlist to remove, first playlist is at index 1");
                        int index = input.nextInt();

                        if (index <= 0 || index > list.length()) {
                            System.out.println("No playlist in that index");

                        } else {
                            list.removeSong(index);
                            System.out.println("playlist delete !!");

                        }
                        break;
                        
                      
                     
          
           //end of switch choice 3
                         
                   }
                      case 3:
                        thir=false;
                  
          } //end of while thir 
           thir=false;
    } //end of switch choice
            
     

 
               
         
       
} // end of sec while loop
}// end of main
}// end of class
    
    
}