/*
 PLAYLIST CLASS/ MAIN CLASS
 */

import java.util.Scanner;

public class Playlist {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
String palylistname1;
        System.out.println("*********************\n");
        System.out.println("---------------------------Welcome All-------------------\n"
              + "------------------- Create Your Own Playlist---------------");
        System.out.println("*********************\n");
        System.out.println("Please Enter your Playlist Name");
        String playlistname = input.nextLine();
        DLL theList = new DLL();
 System.out.println("Do you want to create Another play list");
 
           boolean zero = true;
           while(zero){
                System.out.println("\n Enter 1) yes:  " +  "\n"
                    + " Enter 2) NO: " +  "\n");
            int choice0 = input.nextInt();
            switch(choice0){
                case 1: 
                      System.out.println("Please Enter your Playlist Name");
                    String playlistname1 = input.next();
                    
                    
                     break;
                case 2:
          
 
        boolean first = true;
        while (first) {
            System.out.println("\n Enter 1) To Add Songs To Playlist:  " + playlistname + "\n"
                    + " Enter 2) To remove Songs From Playlist: " + playlistname + "\n"
                    + " Enter 3) To show the songs in Playlist: " + playlistname + "\n"
                    + " Enter 4) To Play The Playlist: " + playlistname + "\n"
                    + " Enter 5) To Exit");
            int choice1 = input.nextInt();
            switch (choice1) {
                case 1:
                    System.out.println("Enter The name of the Song");
                    input.nextLine();
                    String songname = input.nextLine();
                    System.out.println("Enter The Name of the artist");
                    String artist = input.nextLine();
                    System.out.println("Enter The Duration of the song");
                    String duration = input.nextLine();
                    Song s = new Song(songname, artist, duration);
                    theList.addSong(s);
                    System.out.println(songname + " Song is added to playlist " + playlistname + "!!!\n");
                    break;

                case 2:
                    if (theList.length() == 0) {
                        System.out.println("No Songs present in the Playlist: " + playlistname);
                        break;

                    } else {
                        System.out.println("Here is the List of Songs");
                        theList.displayList();
                        System.out.println("Enter The index of the Song to remove, first Song is at index 1");
                        int index = input.nextInt();

                        if (index <= 0 || index > theList.length()) {
                            System.out.println("No Song in that index");

                        } else {
                            theList.removeSong(index);
                            System.out.println("Song Removed !!");

                        }
                        break;
                    }

                case 3:
                    if (theList.length() == 0) {
                        System.out.println("No Songs in the Playlist");
                        break;

                    } else {
                        System.out.println("Here is the List of Songs");
                        theList.displayList();
                        break;

                    }
                case 4:
                    
     
                    
                    if (theList.length() == 0) {
                        System.out.println("No Songs in the Playlist");
                        break;

                    } else {
                        System.out.println("Here is the List of Songs");
                        theList.displayList();
                        System.out.println("");
                        System.out.println("Current Song-----");
                        System.out.println("");
                        node i = theList.getfirst();

                        boolean second = true;
                        while (second) {
                            System.out.println(" \n Enter 1) To play the next song \n"
                                    + " Enter 2) To play the previous song \n"
                                    + " Enter 3) To play the same song again \n"
                                    + " Enter 4) To stop the playlist ");

                            int choice2 = input.nextInt();

                            switch (choice2) {
                                case 1:
                                        
                                    node temp;
                                    temp = theList.head;
                                    node temp1=theList.tail;
                                   if(i==temp1) {
                                     
                                      i=theList.getfirst();
                                     

                                    }
                                    if (i == temp) {

                                        i = temp.next;
                                        System.out.println(i.s.showSong());

                                    } else if (i != temp) {
                                        i = i.next;
                                        System.out.println(i.s.showSong());
                                    }
                                   
                                    break;
                                case 2:

                                    node temp2 = theList.head;
                              

                                    if (i == temp2) {
                                          
                                        System.out.println("Emptylinklist");
                                    } else if (i != temp2) {
                                        i = i.prev;
                                        System.out.println(i.s.showSong());
                                    }

                                    break;
                                case 3:

                                    System.out.println(i.s.showSong());

                                    break;

                                case 4:
                                    second = false;

                                    break;

                                default:
                                    second = false;

                                    break;
                            }
                        }
                    }
                    break;
                    
                case 5:
                    first = false;
                    break;

                default:
                    first = false;

                    break;

            }
        

    }
}
}
    
    }
}