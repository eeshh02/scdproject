/*
NODE CLASS
*/

public class node {

    Song s;
    playlistname p;
    node next;
    node prev;

    node(Song s) {
        this.s = s;
        this.next = null;
        this.prev = null;
    }
    
    node(playlistname p){
        this.p=p;
        this.next=null;
        this.prev=null;
    }

    public void displayDoublyNode() {
        System.out.println(s.showSong() + " ");
    }
       public void displayNode() {
        System.out.println(p.showplaylist() + " ");
    }
    
}