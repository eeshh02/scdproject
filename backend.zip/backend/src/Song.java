/*

PROJECT TITLE : MUSIC PLAYER PLAYLIST
SONG CLASS
 */

public class Song {

    String SongName;
    String Artist;
    String Duration;
  
    public Song(String SongName, String Artist, String Duration) {
        this.SongName = SongName;
        this.Artist = Artist;
        this.Duration = Duration;
        
    }

    public String showSong() {
        return (SongName + "----->" + Artist + "----->" + Duration);
    }
    
   
}