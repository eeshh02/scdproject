/*
DSA THEORY SEMESTER PROJECT
GROUP MEMBERS : 1- M. ZULQARNAIN (089)
                2- MALIK ZOHAIB ALTAF (079)
                3- EESHAH QAMAR (066)
PROJECT TITLE : MUSIC PLAYER PLAYLIST
SONG CLASS
 */

public class Song {

    String SongName;
    String Artist;
    String Duration;

    public Song(String SongName, String Artist, String Duration) {
        this.SongName = SongName;
        this.Artist = Artist;
        this.Duration = Duration;
    }

    public String showSong() {
        return (SongName + "----->" + Artist + "----->" + Duration);
    }
}